// Browser acceptance test for the Doom WASM port (AGENT-PROPOSED criteria; see
// artifacts/runs/*/tester/prepare/attempt-1/proposed-criteria.md). Exit 0 only if every required
// check passes. Env: DIST_DIR (default dist), OUT_DIR (evidence), SOAK_SECONDS (default 300),
// QUICK=1 shortens the soak and forces a nonzero exit (3): partial runs never count as pass.
import http from 'node:http'; import fs from 'node:fs'; import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { chromium } from 'playwright'; import { PNG } from 'pngjs';
import { stats, diffFrac, bestShift, VIEW, STATUSBAR, AMMO } from './lib/frames.mjs';

const root = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');
const DIST = path.resolve(root, process.env.DIST_DIR || 'dist');
const OUT = path.resolve(root, process.env.OUT_DIR || `artifacts/runs/manual-${Date.now()}/tester/playtest`);
const QUICK = process.env.QUICK === '1';
const SOAK = QUICK ? 15 : Number(process.env.SOAK_SECONDS || 300);
fs.mkdirSync(path.join(OUT, 'screens'), { recursive: true });

const results = []; const log = [];
const rec = (id, status, detail = '') => { results.push({ id, status, detail }); console.log(`${status.padEnd(10)} ${id} ${detail}`); };
const check = (id, cond, detail = '') => rec(id, cond ? 'PASS' : 'FAIL', detail);
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
function finish(extra = {}) {
  const failed = results.filter((r) => r.status === 'FAIL').length;
  const unverified = results.filter((r) => r.status === 'UNVERIFIED').length;
  let code = failed ? 1 : 0; if (!code && QUICK) code = 3;
  const out = { status: code === 0 ? 'PASS' : 'FAIL', quick: QUICK, soak_seconds: SOAK, failed, unverified, results, ...extra };
  fs.writeFileSync(path.join(OUT, 'playtest-results.json'), JSON.stringify(out, null, 2));
  fs.writeFileSync(path.join(OUT, 'browser-console.log'), log.join('\n'));
  console.log(`playtest: ${out.status} failed=${failed} unverified(not-in-scope, listed)=${unverified}${QUICK ? ' QUICK=partial' : ''}`);
  process.exit(code);
}

// Missing dist is a hard failure, not a skip.
for (const f of ['index.html', 'doom.wasm']) if (!fs.existsSync(path.join(DIST, f))) { rec('B0.dist-present', 'FAIL', `${path.join(DIST, f)} missing`); finish(); }
rec('B0.dist-present', 'PASS');

const MIME = { '.html': 'text/html', '.js': 'text/javascript', '.wasm': 'application/wasm', '.data': 'application/octet-stream', '.css': 'text/css' };
const badResponses = [];
const server = http.createServer((req, res) => {
  const p = path.join(DIST, decodeURIComponent(new URL(req.url, 'http://x').pathname).replace(/^\/$/, '/index.html'));
  if (!p.startsWith(DIST) || !fs.existsSync(p) || fs.statSync(p).isDirectory()) { badResponses.push(`404 ${req.url}`); res.writeHead(404).end(); return; }
  res.writeHead(200, { 'content-type': MIME[path.extname(p)] || 'application/octet-stream' }); fs.createReadStream(p).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const url = `http://127.0.0.1:${server.address().port}/`;

const browser = await chromium.launch();
const page = await (await browser.newContext({ viewport: { width: 800, height: 600 }, deviceScaleFactor: 1 })).newPage();
const errors = [];
page.on('console', (m) => { log.push(`[${m.type()}] ${m.text()}`); if (m.type() === 'error') errors.push(m.text()); });
page.on('pageerror', (e) => { log.push(`[pageerror] ${e.message}`); errors.push(`pageerror: ${e.message}`); });
page.on('requestfailed', (r) => errors.push(`requestfailed: ${r.url()}`));
await page.addInitScript(() => {
  window.__raf = 0; (function t() { window.__raf++; requestAnimationFrame(t); })();
  window.__long = []; try { new PerformanceObserver((l) => l.getEntries().forEach((e) => window.__long.push(e.duration))).observe({ entryTypes: ['longtask'] }); } catch {}
});

let n = 0;
async function shot(name) {
  const buf = await page.locator('#canvas').screenshot();
  fs.writeFileSync(path.join(OUT, 'screens', `${String(++n).padStart(3, '0')}-${name}.png`), buf);
  return PNG.sync.read(buf);
}
const key = async (k, hold = 80) => { await page.keyboard.down(k); await sleep(hold); await page.keyboard.up(k); };
// Doom has momentum/friction: motion legitimately decays for ~1.5s after key-up. Poll until two
// consecutive 300ms steps differ <2% (settled) instead of assuming a fixed delay.
async function settle(maxMs = 4000) {
  const t = Date.now(); let prev = await shot('settle');
  while (Date.now() - t < maxMs) { await sleep(300); const cur = await shot('settle'); const d = diffFrac(prev, cur, VIEW); prev = cur; if (d < 0.02) return { frame: cur, ms: Date.now() - t, settled: true }; }
  return { frame: prev, ms: Date.now() - t, settled: false };
}
const hasCrash = () => errors.some((e) => /abort|RuntimeError|unreachable|Aborted/i.test(e));

try {
  await page.goto(url);
  check('B1.canvas-640x400', await page.evaluate(() => { const c = document.getElementById('canvas'); return !!c && c.width === 640 && c.height === 400; }), 'canvas#canvas intrinsic size');
  // Boot: wait for a non-black, multi-colour frame.
  let boot = null; const t0 = Date.now();
  while (Date.now() - t0 < 60000) { const p = await shot('boot'); const s = stats(p); if (s.darkFrac < 0.9 && s.distinctColors > 16) { boot = { p, s }; break; } await sleep(500); }
  check('B2.boot-renders-frame', !!boot, boot ? `after ${Date.now() - t0}ms colors=${boot.s.distinctColors}` : 'no non-black frame in 60s');
  if (!boot) finish();
  check('B3.opaque-pixels', boot.s.transparentFrac === 0, `transparentFrac=${boot.s.transparentFrac}`);
  check('B4.channel-order', boot.s.meanR > boot.s.meanB, `meanR=${boot.s.meanR.toFixed(1)} meanB=${boot.s.meanB.toFixed(1)} (title/menu are warm; swap => blue)`);
  check('B5.no-load-errors', errors.length === 0 && badResponses.length === 0, [...errors, ...badResponses].slice(0, 5).join(' | '));
  await page.locator('#canvas').click({ position: { x: 5, y: 5 } }).catch(() => {}); // focus only

  // Animation liveness (T1): requestAnimationFrame keeps firing; no multi-second main-thread stalls.
  const r0 = await page.evaluate(() => window.__raf); await sleep(3000); const r1 = await page.evaluate(() => window.__raf);
  check('T1.main-thread-responsive', (r1 - r0) / 3 >= 20, `${((r1 - r0) / 3).toFixed(1)} rAF/s over 3s (need >=20)`);

  // Menu navigation -> new game E1M1 (episode + skill menus with defaults).
  const title = await shot('title');
  await key('Enter'); await sleep(1200); const menu = await shot('main-menu');
  check('M1.enter-opens-menu', diffFrac(title, menu, VIEW) > 0.01, `diff=${diffFrac(title, menu, VIEW).toFixed(3)}`);
  await key('Enter'); await sleep(900); await key('Enter'); await sleep(900); await key('Enter'); // New Game, episode, skill
  await sleep(6000); // wipe + level load
  const lvl = await shot('level-start'); const sb = stats(lvl, STATUSBAR);
  check('G1.level-started', diffFrac(menu, lvl) > 0.2 && sb.distinctColors > 20, `diff-from-menu=${diffFrac(menu, lvl).toFixed(2)} statusbarColors=${sb.distinctColors}`);
  check('B6.level-colors', stats(lvl, VIEW).meanR >= stats(lvl, VIEW).meanB * 0.9, 'E1M1 view not blue-biased');

  // Idle stability: nothing should move with no input (guards "frames change by themselves").
  const i1 = await shot('idle-a'); await sleep(600); const i2 = await shot('idle-b');
  check('G2.idle-stable', diffFrac(i1, i2, VIEW) < 0.02, `diff=${diffFrac(i1, i2, VIEW).toFixed(4)}`);

  // Turning: right turn => scene shifts left (negative); left turn shifts back (positive). Key release stops it.
  const a = await shot('turn-start');
  await page.keyboard.down('ArrowRight'); await sleep(350); await page.keyboard.up('ArrowRight'); await sleep(700);
  const b = await shot('turn-right'); const sr = bestShift(a, b);
  check('I1.turn-right', sr.shift <= -8 && sr.err < sr.err0, `shift=${sr.shift}px err=${sr.err.toFixed(1)} err0=${sr.err0.toFixed(1)}`);
  const b2 = await shot('turn-right-settled'); check('I2.turn-stops-on-release', diffFrac(b, b2, VIEW) < 0.02, `diff=${diffFrac(b, b2, VIEW).toFixed(4)}`);
  await page.keyboard.down('ArrowLeft'); await sleep(350); await page.keyboard.up('ArrowLeft'); await sleep(700);
  const c = await shot('turn-left'); const sl = bestShift(b, c);
  check('I3.turn-left', sl.shift >= 8 && sl.err < sl.err0, `shift=${sl.shift}px`);

  // Movement: forward changes view; backward returns toward start; release halts motion.
  const s0 = await shot('move-start');
  await page.keyboard.down('ArrowUp'); await sleep(800); const mid = await shot('move-fwd-held'); await sleep(300); const mid2 = await shot('move-fwd-held2');
  check('I4.forward-moves', diffFrac(s0, mid, VIEW) > 0.05 && diffFrac(mid, mid2, VIEW) > 0.01, `start-vs-mid=${diffFrac(s0, mid, VIEW).toFixed(3)} still-moving=${diffFrac(mid, mid2, VIEW).toFixed(3)}`);
  await page.keyboard.up('ArrowUp');
  const fs1 = await settle(); const f2 = fs1.frame; await sleep(500); const f3 = await shot('move-fwd-stopped');
  check('I5.forward-stops-on-release', fs1.settled && diffFrac(f2, f3, VIEW) < 0.02, `settled=${fs1.settled} after ${fs1.ms}ms (momentum allowed up to 4s); later-diff=${diffFrac(f2, f3, VIEW).toFixed(4)}`);
  await page.keyboard.down('ArrowDown'); await sleep(1100); await page.keyboard.up('ArrowDown');
  const back = (await settle()).frame;
  check('I6.backward-returns', diffFrac(s0, back, VIEW) < diffFrac(s0, f2, VIEW) * 0.7, `start-vs-back=${diffFrac(s0, back, VIEW).toFixed(3)} start-vs-fwd=${diffFrac(s0, f2, VIEW).toFixed(3)}`);

  // Focus loss must release held keys (stuck-key regression).
  // Hold a TURN key (never blocked by walls, so a stuck key keeps the view changing forever).
  await page.keyboard.down('ArrowRight'); await sleep(500);
  const turning = await shot('blur-turning'); await sleep(300); const turning2 = await shot('blur-turning-b');
  check('I7a.turn-held-keeps-changing', diffFrac(turning, turning2, VIEW) > 0.02, `diff=${diffFrac(turning, turning2, VIEW).toFixed(4)} (precondition: key effective before blur)`);
  await page.evaluate(() => { window.dispatchEvent(new Event('blur')); document.dispatchEvent(new Event('visibilitychange')); });
  const bs = await settle(); await sleep(500); const g2 = await shot('blur-b');
  check('I7.blur-releases-keys', bs.settled && diffFrac(bs.frame, g2, VIEW) < 0.02, `settled=${bs.settled} after ${bs.ms}ms; later-diff=${diffFrac(bs.frame, g2, VIEW).toFixed(4)} (key still physically down)`);
  await page.keyboard.up('ArrowRight'); await sleep(500);

  // Fire: ammo counter changes and the weapon/view animates; release stops firing.
  const pre = await shot('fire-pre');
  await key('Control', 120); await sleep(250); const flash = await shot('fire-anim'); await sleep(1500); const post = await shot('fire-post');
  check('C1.fire-animates', diffFrac(pre, flash, VIEW) > 0.005, `view-diff=${diffFrac(pre, flash, VIEW).toFixed(4)}`);
  check('C2.fire-decrements-ammo', diffFrac(pre, post, AMMO) > 0.02, `ammo-region-diff=${diffFrac(pre, post, AMMO).toFixed(3)} (persisting after weapon returns to rest)`);
  const q1 = await shot('fire-rest-a'); await sleep(600); const q2 = await shot('fire-rest-b');
  check('C3.fire-stops-on-release', diffFrac(q1, q2, VIEW) < 0.02, `diff=${diffFrac(q1, q2, VIEW).toFixed(4)}`);

  // Use key + automap + menu overlay do not crash and change the display as expected.
  await key('Space'); await sleep(500);
  const am0 = await shot('automap-pre'); await key('Tab'); await sleep(700); const am1 = await shot('automap-on');
  check('U1.automap-toggles', diffFrac(am0, am1) > 0.2, `diff=${diffFrac(am0, am1).toFixed(3)}`);
  await key('Tab'); await sleep(700); const am2 = await shot('automap-off');
  check('U2.automap-returns', diffFrac(am0, am2, VIEW) < 0.1, `diff=${diffFrac(am0, am2, VIEW).toFixed(3)}`);
  await key('Escape'); await sleep(800); const esc = await shot('esc-menu');
  check('U3.escape-opens-menu', diffFrac(am2, esc, VIEW) > 0.01, `diff=${diffFrac(am2, esc, VIEW).toFixed(3)}`);
  await key('Escape'); await sleep(800); const esc2 = await shot('esc-closed');
  check('U4.escape-closes-menu', diffFrac(esc, esc2, VIEW) > 0.01, `diff=${diffFrac(esc, esc2, VIEW).toFixed(3)}`);

  // T2: engine tic rate via coder-exported cap_tic_count (contract v2). Missing export => UNVERIFIED, not PASS.
  const tc = async () => page.evaluate(() => (window.Module && window.Module._cap_tic_count) ? window.Module._cap_tic_count() : null);
  const ta = await tc(); const tms = Date.now(); await sleep(4000); const tb = await tc(); const rate = ((tb - ta) / ((Date.now() - tms) / 1000));
  if (ta === null || tb === null) rec('T2.35-tics-per-second', 'UNVERIFIED', 'Module._cap_tic_count not exported');
  else check('T2.35-tics-per-second', rate >= 31.5 && rate <= 38.5, `${rate.toFixed(2)} tics/s over 4s (need 35 +/-10%)`);

  // Soak (R6): scripted input for SOAK seconds; the page must stay alive with no errors/aborts.
  const keys = ['ArrowUp', 'ArrowLeft', 'ArrowRight', 'ArrowDown', 'Control', 'Space', 'Shift'];
  let seed = 12345; const rnd = () => (seed = (seed * 1103515245 + 12345) & 0x7fffffff) / 0x7fffffff;
  const t1 = Date.now(), r2 = await page.evaluate(() => window.__raf); let moved = 0, last = await shot('soak-start');
  while (Date.now() - t1 < SOAK * 1000) {
    const k = keys[Math.floor(rnd() * keys.length)]; await key(k, 100 + Math.floor(rnd() * 600)); await sleep(100);
    if (Math.floor((Date.now() - t1) / 1000) % 20 === 0) { const s = await shot('soak'); if (diffFrac(last, s) > 0.005) moved++; last = s; }
  }
  const r3 = await page.evaluate(() => window.__raf), longMax = await page.evaluate(() => Math.max(0, ...window.__long));
  check('R1.soak-no-errors', !hasCrash() && errors.length === 0, `${SOAK}s; errors=${errors.slice(0, 3).join(' | ')}`);
  check('R2.soak-still-rendering', (r3 - r2) / SOAK >= 20 && stats(last).darkFrac < 0.95, `rAF/s=${((r3 - r2) / SOAK).toFixed(1)} visibleFrame=${stats(last).darkFrac < 0.95}`);
  check('R3.no-long-stalls', longMax < 1500, `max longtask=${longMax.toFixed(0)}ms (must be <1500)`);
  check('R4.soak-frames-changed', moved > 0, `sampled frames that differed: ${moved}`);
} catch (e) {
  rec('X.harness-exception', 'FAIL', String(e && e.stack || e).split('\n').slice(0, 3).join(' '));
}
for (const [id, why] of [['A1.audio', 'scope undecided; an active AudioContext would not prove correct sound/music'],
  ['P1.save-persistence', 'scope undecided'], ['G3.door-use-and-level-exit', 'no stable cross-build oracle; manual/protocol check']]) rec(id, 'UNVERIFIED', why);
await page.screenshot({ path: path.join(OUT, 'screens', 'final-page.png') }).catch(() => {});
await browser.close().catch(() => {}); server.close();
finish();
