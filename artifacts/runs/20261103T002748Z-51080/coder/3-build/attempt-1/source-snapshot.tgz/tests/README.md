# Verification

Keep verification code here, including browser checks, fixtures, and tests
for the loop itself. You design the checks; no test suite is provided.

See [the acceptance criteria and evidence requirements](../README.md#evaluate-the-system-you-built).
Document how to run your checks and what each one establishes.

Save test results, logs, screenshots, and recordings in `artifacts/`.
Keep acceptance checks outside the coder's write permissions using your
sandbox/tool configuration; a folder name alone does not enforce access.

## Suite (tester-owned; criteria are AGENT-PROPOSED, not student-approved)

Run: `source ~/Developer/emsdk/emsdk_env.sh && tests/verify.sh` (RUN_ID, SOAK_SECONDS, QUICK=1 optional).
Evidence goes to `artifacts/runs/$RUN_ID/tester/verify-*/` (identity.txt, logs, screenshots, playtest-results.json).
Exit 0 only when tooling, build, selftest and every required playtest check pass; `QUICK=1` never exits 0.

| File | Establishes |
| --- | --- |
| `verify.sh` | tooling check, source identity, selftest, `make clean && make all`, playtest |
| `selftest.mjs` | pixel helpers FAIL on black, channel-swapped, transparent, static, wrongly shifted frames (no build needed) |
| `playtest.mjs` | Chromium: load/console errors, boot frame, colors, rAF liveness, menu -> E1M1, turn/move/fire/release, blur, automap, Esc menu, soak |
| `lib/frames.mjs` | region diff / color stats / horizontal-shift estimation on canvas screenshots |

Limits: outcomes are inferred from pixels (no engine state hook); audio, persistence, door/level-exit and the
35 tics/s rate are listed as UNVERIFIED in every result. Ammo/status regions assume the stock 320x200 layout.
Test deps: `npm ci` in `tests/` (network needed once; Playwright 1.49.1, pngjs 7.0.0).
