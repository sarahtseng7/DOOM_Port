// WebAssembly platform layer for doomgeneric (coder-owned).
// DG_* callbacks forward to the cap_* functions declared in capstone_bridge.h.
// Default (weak) cap_* implementations live in cap_fallback.c; specialist
// modules override them with strong definitions.

#include <stdint.h>

#include <emscripten.h>

#include "capstone_bridge.h"

extern int gametic;

static int cap_started;

void DG_Init()
{
    cap_render_init();
    cap_input_init();
    cap_audio_init();
}

void DG_DrawFrame()
{
    cap_render_present(DG_ScreenBuffer);
}

void DG_SleepMs(uint32_t ms)
{
    cap_sleep_ms(ms);
}

uint32_t DG_GetTicksMs()
{
    return cap_time_ms();
}

int DG_GetKey(int *pressed, unsigned char *key)
{
    return cap_input_poll(pressed, key);
}

void DG_SetWindowTitle(const char *title)
{
    cap_set_title(title);
}

int cap_bridge_version(void)
{
    return CAP_BRIDGE_VERSION;
}

int cap_ready(void)
{
    return cap_started;
}

const void *cap_framebuffer_ptr(void)
{
    return DG_ScreenBuffer;
}

int cap_tic_count(void)
{
    return gametic;
}

int main(int argc, char **argv)
{
    static char *args[] = { "doom", "-iwad", CAP_WAD_PATH, NULL };
    (void)argc;
    (void)argv;

    doomgeneric_Create(3, args);
    cap_started = 1;

    // ASYNCIFY build: cap_sleep_ms yields to the browser inside the engine's
    // tic waits; the explicit sleep(0) yields once per frame otherwise.
    for (;;) {
        doomgeneric_Tick();
        emscripten_sleep(0);
    }
    return 0;
}
