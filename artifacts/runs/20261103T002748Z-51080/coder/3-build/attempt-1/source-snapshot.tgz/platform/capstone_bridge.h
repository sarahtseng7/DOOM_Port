// Shared bridge contract between the coder-owned DG adapters
// (platform/doomgeneric_wasm.c) and the specialist modules
// (render_timing.*, input_audio.*). AGENT-PROPOSED; not student-approved.
// Full prose: artifacts/runs/20261103T002748Z-51080/coder/plan/attempt-1/interface-contract.md
// Only the coder role edits this file; request changes via your report.
#ifndef CAPSTONE_BRIDGE_H
#define CAPSTONE_BRIDGE_H

#include <stdint.h>

#include "doomgeneric.h"

#ifdef __EMSCRIPTEN__
#include <emscripten.h>
#define CAP_EXPORT EMSCRIPTEN_KEEPALIVE
#else
#define CAP_EXPORT
#endif

#ifdef __cplusplus
extern "C" {
#endif

// v2: added cap_tic_count(). Specialist hooks have WEAK defaults in
// platform/cap_fallback.c; a strong definition in another platform/*.c wins.
#define CAP_BRIDGE_VERSION 2

// Framebuffer: DG_ScreenBuffer is DOOMGENERIC_RESX x DOOMGENERIC_RESY
// (640x400) pixel_t (uint32_t). Memory bytes per pixel are B,G,R,0 (alpha is
// NOT set); the render module converts to opaque RGBA for canvas ImageData.
#define CAP_FB_WIDTH   DOOMGENERIC_RESX
#define CAP_FB_HEIGHT  DOOMGENERIC_RESY
#define CAP_FB_BYTES   (CAP_FB_WIDTH * CAP_FB_HEIGHT * 4)

// Paths inside the Emscripten virtual FS.
#define CAP_WAD_PATH   "/doom1.wad"

// ---- Owner: coder (platform/doomgeneric_wasm.c) -------------------------
// The DG_* callbacks in doomgeneric.h are thin adapters that forward to the
// cap_* functions below. Only the coder defines the DG_* symbols and main().
CAP_EXPORT int      cap_bridge_version(void);        // returns CAP_BRIDGE_VERSION
CAP_EXPORT const void *cap_framebuffer_ptr(void);    // DG_ScreenBuffer address (valid after startup)
CAP_EXPORT int      cap_tic_count(void);             // engine gametic (35/s at full speed); for T2 checks
CAP_EXPORT int      cap_ready(void);                 // 1 once doomgeneric_Create() returned

// ---- Owner: coder_render_timing (platform/render_timing.c) --------------
void     cap_render_init(void);                      // from DG_Init
void     cap_render_present(const pixel_t *fb);      // from DG_DrawFrame; must not retain fb
uint32_t cap_time_ms(void);                          // from DG_GetTicksMs; monotonic, ms
                                                     // since page start, MUST be nonzero
                                                     // by the first engine call (i_timer.c
                                                     // treats basetime==0 as unset)
void     cap_sleep_ms(uint32_t ms);                  // from DG_SleepMs (engine wipe/tic waits)
void     cap_set_title(const char *title);           // from DG_SetWindowTitle

// ---- Owner: coder_input_audio (platform/input_audio.c) ------------------
void cap_input_init(void);                           // from DG_Init
int  cap_input_poll(int *pressed, unsigned char *doom_key); // from DG_GetKey; 1=event
                                                     // returned, 0=queue empty.
                                                     // doom_key is a doomkeys.h code.
CAP_EXPORT void cap_input_event(int pressed, int doom_key); // JS->C enqueue (bounded queue)
CAP_EXPORT void cap_input_reset(void);               // release all keys (blur/visibility)
void cap_audio_init(void);                           // optional; no-op until audio scope approved

#ifdef __cplusplus
}
#endif

#endif // CAPSTONE_BRIDGE_H
