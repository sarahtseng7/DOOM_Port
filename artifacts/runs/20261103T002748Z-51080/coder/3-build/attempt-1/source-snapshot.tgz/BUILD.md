# Building the Doom WebAssembly port

Toolchain: Emscripten **4.0.18** (`source ~/Developer/emsdk/emsdk_env.sh`), GNU make, Node (tests only).

    make        # builds build/*.o and dist/{index.html,doom.js,doom.wasm,doom.data}
    make clean  # removes build/ and dist/

- Engine sources: all `third_party/doomgeneric/*.c` except `dummy.c`, `doomgeneric_sdl.c`; platform code: `platform/*.c`.
- WAD packaging: `assets/doom1.wad` is embedded via `--preload-file` at `/doom1.wad` in `dist/doom.data`.
- `web/index.html` is copied to `dist/index.html`. Serve `dist/` over HTTP (not `file://`).
- JS/C bridge exports are listed in the Makefile `EXPORTED_FUNCTIONS`; see `platform/capstone_bridge.h`.
- Acceptance: `tests/verify.sh` (tester-owned); `QUICK=1` is partial and never exits 0.
